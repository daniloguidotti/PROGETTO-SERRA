import random

def crea_tabellone(dimensione):
    return [["O" for _ in range(dimensione)] for _ in range(dimensione)]

def stampa_tabellone(tabellone):
    for riga in tabellone:
        print(" ".join(riga))

def posizione_casuale(tabellone):
    return random.randint(0, len(tabellone) - 1), random.randint(0, len(tabellone[0]) - 1)

def posiziona_navi(tabellone, num_navi):
    for _ in range(num_navi):
        riga, colonna = posizione_casuale(tabellone)
        while tabellone[riga][colonna] == "X":
            riga, colonna = posizione_casuale(tabellone)
        tabellone[riga][colonna] = "X"

def mossa_valida(riga, colonna, tabellone):
    return 0 <= riga < len(tabellone) and 0 <= colonna < len(tabellone[0])

def gioca():
    dimensione_tabellone = 5
    numero_navi = 3
    tabellone = crea_tabellone(dimensione_tabellone)

    print("Benvenuto nella Battaglia Navale!")
    stampa_tabellone(tabellone)

    posiziona_navi(tabellone, numero_navi)

    for turno in range(10):
        print(f"\nTurno {turno + 1}")

        riga = int(input("Inserisci numero di riga (0-4): "))
        colonna = int(input("Inserisci numero di colonna (0-4): "))

        if not mossa_valida(riga, colonna, tabellone):
            print("Coordinate non valide! Riprova.")
            continue

        if tabellone[riga][colonna] == "X":
            print("Congratulazioni! Hai colpito una nave!")
            tabellone[riga][colonna] = "!"
        else:
            print("Mancato! Riprova.")
            if tabellone[riga][colonna] != "O":
                print("Hai già sparato in questa posizione.")

        stampa_tabellone(tabellone)

        if all(cella != "X" for riga in tabellone for cella in riga):
            print("Congratulazioni! Hai affondato tutte le navi!")
            break

    else:
        print("Partita conclusa. Hai esaurito i tentativi. Riprova!")

if __name__ == "__main__":
    gioca()
