from tkinter import *
from tkinter import messagebox
import time

tk = Tk()
app_running = True

#size of application
size_canvas_x = 600 
size_canvas_y = 600

def on_closing():
    global app_running
    if messagebox.askokcancel("Uscita", "Vuoi uscire dal gioco?"):
        app_running = False
        tk.destroy()

tk.protocol("WM_DELETE_WINDOW", on_closing)
tk.title("Battaglia Navale")
tk.resizable(0, 0) #change size of application
tk.wm_attributes("-topmost", 1) #up of the all applications
canvas = Canvas(tk, width= size_canvas_x, height=size_canvas_y, bd=0, highlightthickness=0)
canvas.create_rectangle(0, 0, size_canvas_x, size_canvas_y, fill="white")
canvas.pack()
tk.update()


while app_running:
    if app_running:
        tk.update_idletasks()
        tk.update()
        
    time.sleep(0.005)
    
